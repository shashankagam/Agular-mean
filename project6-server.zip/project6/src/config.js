const DB_config= {
    host     : 'localhost',
    user     : 'root',
    password : 'robince',
    database : 'demo1'
  };

module.exports={DB_config};
