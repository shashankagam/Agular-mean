import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wbed',
  templateUrl: './wbed.component.html',
  styleUrls: ['./wbed.component.css']
})
export class WbedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
