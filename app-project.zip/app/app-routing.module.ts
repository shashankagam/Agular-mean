import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HomeComponent } from './home/home.component';
import{ ForgotPasswordComponent}from './forgot-password/forgot-password.component'
import { PersonalInfoComponent } from './personal-info/personal-info.component';

import { ContactUsComponent } from './contact-us/contact-us.component';

import { IndianComponent } from './indian/indian.component';
import { IbedroomsComponent } from './ibedrooms/ibedrooms.component';
import { IbathroomsComponent } from './ibathrooms/ibathrooms.component';

import { IkitchenComponent } from './ikitchen/ikitchen.component';
import { IlivingComponent } from './iliving/iliving.component';
import { AlivingComponent } from './aliving/aliving.component';
import { AbedroomsComponent } from './abedrooms/abedrooms.component';
import { AbathroomsComponent } from './abathrooms/abathrooms.component';
import { WbathComponent } from './wbath/wbath.component';
import { WbedComponent } from './wbed/wbed.component';
import { WkitComponent } from './wkit/wkit.component';
import { Asian1Component } from './asian1/asian1.component';
import { Western1Component } from './western1/western1.component';
import { AkitComponent } from './akit/akit.component';
import {WlivingComponent}from './wliving/wliving.component';
import { DeleteComponent } from './delete/delete.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  {path: 'home', component: HomeComponent},
    
  { path: 'personal-info', component: PersonalInfoComponent },
  { path: 'contact-us', component: ContactUsComponent },

  { path: 'delete', component: DeleteComponent },
    
  
  {path: 'forgotpassword', component:ForgotPasswordComponent},
  { path: '', redirectTo: '/login', pathMatch: 'full' },


  { path: 'home', component: HomeComponent },
  { path: 'wliving', component: WlivingComponent },
  { path: 'indian', component: IndianComponent },
  { path: 'ibedrooms', component: IbedroomsComponent },
  { path: 'ibathrooms', component: IbathroomsComponent },
  
  { path: 'ikitchen', component: IkitchenComponent },
  { path: 'iliving', component: IlivingComponent },
  { path: 'aliving', component: AlivingComponent },
  { path: 'abedrooms', component: AbedroomsComponent },
  { path: 'abathrooms', component: AbathroomsComponent },
  { path: 'wbath', component: WbathComponent },
  { path: 'wbed', component: WbedComponent },
  { path: 'wkit', component: WkitComponent },
  { path: 'asian1', component: Asian1Component },
  { path: 'western1', component: Western1Component },
  { path: 'akit', component: AkitComponent },

  { path: '**', component: PageNotFoundComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}