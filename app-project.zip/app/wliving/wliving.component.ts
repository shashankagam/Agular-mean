import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wliving',
  templateUrl: './wliving.component.html',
  styleUrls: ['./wliving.component.css']
})
export class WlivingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
