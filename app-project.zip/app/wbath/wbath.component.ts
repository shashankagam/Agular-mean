import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wbath',
  templateUrl: './wbath.component.html',
  styleUrls: ['./wbath.component.css']
})
export class WbathComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
