import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import{faChessKnight} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.css']
})
export class PageNotFoundComponent implements OnInit {
  public faChessKnight= faChessKnight;

  constructor(private router: Router, private http: HttpClient) { }

  ngOnInit(): void {
  }
  processLogIn() {
    sessionStorage.removeItem('sid');
    this.router.navigate(['login']);

  }
    
}
