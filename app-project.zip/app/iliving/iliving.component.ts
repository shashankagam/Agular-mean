import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iliving',
  templateUrl: './iliving.component.html',
  styleUrls: ['./iliving.component.css']
})
export class IlivingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
