import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import{faChessKnight} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-western1',
  templateUrl: './western1.component.html',
  styleUrls: ['./western1.component.css']
})
export class Western1Component implements OnInit {
  public faChessKnight= faChessKnight;
  constructor(private router: Router) { }

  gotoRoute() {
    this.router.navigate(['wliving']);
  }
  gotoibed() {
    this.router.navigate(['wbed']);
  }
  gotowkit() {
    this.router.navigate(['wkit']);
  }
  gotoibath() {
    this.router.navigate(['wbath'])
  }

  ngOnInit(): void {
  }

}