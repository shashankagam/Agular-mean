import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HomeComponent } from './home/home.component';
import { PersonalInfoComponent } from './personal-info/personal-info.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { IndianComponent } from './indian/indian.component';
import { Western1Component } from './western1/western1.component';
import { Asian1Component } from './asian1/asian1.component';
import { IlivingComponent } from './iliving/iliving.component';
import { IbedroomsComponent } from './ibedrooms/ibedrooms.component';
import { IkitchenComponent } from './ikitchen/ikitchen.component';
import { IbathroomsComponent } from './ibathrooms/ibathrooms.component';
import { WlivingComponent } from './wliving/wliving.component';
import { WbedComponent } from './wbed/wbed.component';
import { WkitComponent } from './wkit/wkit.component';
import { WbathComponent } from './wbath/wbath.component';
import { AlivingComponent } from './aliving/aliving.component';
import { AbedroomsComponent } from './abedrooms/abedrooms.component';
import { AbathroomsComponent } from './abathrooms/abathrooms.component';
import { AkitComponent } from './akit/akit.component';
import { DeleteComponent } from './delete/delete.component';
//import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
//import { LogoutModalComponent } from './logout-modal/logout-modal.component';
//import { DetailsModalComponent } from './details-modal/details-modal.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    PageNotFoundComponent,
    HomeComponent,
    PersonalInfoComponent,
    ContactUsComponent,
    ForgotPasswordComponent,
    IndianComponent,
    Western1Component,
    Asian1Component,
    IlivingComponent,
    IbedroomsComponent,
    IkitchenComponent,
    IbathroomsComponent,
    WlivingComponent,
    WbedComponent,
    WkitComponent,
    WbathComponent,
    AlivingComponent,
    AbedroomsComponent,
    AbathroomsComponent,
    AkitComponent,
    DeleteComponent,
    //LogoutModalComponent,
    //DetailsModalComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FontAwesomeModule,
    ReactiveFormsModule,
    HttpClientModule,
    //NgbModule,
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}