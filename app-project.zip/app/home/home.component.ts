import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import{faChessKnight} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public faChessKnight= faChessKnight;
  
  constructor( private router: Router) { }

  ngOnInit(): void {
    if (!sessionStorage.getItem('sid')) {
      this.router.navigate(['login']);
    }
  }

  processLogout() {
    sessionStorage.removeItem('sid');
    this.router.navigate(['login']); 
  };

  gotoRoute() {
    this.router.navigate(['western1']);
  }
  gotoindian() {
    this.router.navigate(['indian']);
  }
  gotoasian() {
    this.router.navigate(['asian1'])
  }
  
 

}
