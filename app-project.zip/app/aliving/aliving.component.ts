import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aliving',
  templateUrl: './aliving.component.html',
  styleUrls: ['./aliving.component.css']
})
export class AlivingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
