import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-abedrooms',
  templateUrl: './abedrooms.component.html',
  styleUrls: ['./abedrooms.component.css']
})
export class AbedroomsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
