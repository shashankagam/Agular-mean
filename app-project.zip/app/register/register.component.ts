import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

import{faChessKnight} from '@fortawesome/free-solid-svg-icons';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  
  public uiInvalidCredential = false;
  public faChessKnight= faChessKnight;

  public fbFormGroup = this.fb.group({
    username: ['',[Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
    password: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
    email: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20)]],
    mobile: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(20), Validators.pattern('^[0-9]*$')]],
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private http: HttpClient
  ) {}

  ngOnInit(): void {
  }

  async registerHere() {
    const data = this.fbFormGroup.value;
    const url = 'http://localhost:3000/adduser';

    await this.http.post(url, data).toPromise();

    this.router.navigate(['login']);
  }

}
