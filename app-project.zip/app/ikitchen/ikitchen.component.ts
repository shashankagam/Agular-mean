import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ikitchen',
  templateUrl: './ikitchen.component.html',
  styleUrls: ['./ikitchen.component.css']
})
export class IkitchenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
