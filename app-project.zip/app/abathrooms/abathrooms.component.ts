import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-abathrooms',
  templateUrl: './abathrooms.component.html',
  styleUrls: ['./abathrooms.component.css']
})
export class AbathroomsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
