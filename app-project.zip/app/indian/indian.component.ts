import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import{faChessKnight} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-indian',
  templateUrl: './indian.component.html',
  styleUrls: ['./indian.component.css']
})
export class IndianComponent implements OnInit {
  public faChessKnight= faChessKnight;

  constructor(private router: Router) { }

  gotoRoute() {
    this.router.navigate(['iliving']);
  }
  gotoibed() {
    this.router.navigate(['ibedrooms']);
  }
  gotoikit() {
    this.router.navigate(['ikitchen']);
  }
  gotoibath() {
    this.router.navigate(['ibathrooms'])
  }

  ngOnInit(): void {
  }

}
