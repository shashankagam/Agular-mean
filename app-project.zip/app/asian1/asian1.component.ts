import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import{faChessKnight} from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-asian1',
  templateUrl: './asian1.component.html',
  styleUrls: ['./asian1.component.css']
})
export class Asian1Component implements OnInit {
  public faChessKnight= faChessKnight;
  
  constructor(private router: Router) { }

  gotoRoute() {
    this.router.navigate(['aliving']);
  }
  gotoibed() {
    this.router.navigate(['abedrooms']);
  }
  gotoikit() {
    this.router.navigate(['akit']);
  }
  gotoibath() {
    this.router.navigate(['abathrooms'])
  }
  ngOnInit(): void {
  }




}

