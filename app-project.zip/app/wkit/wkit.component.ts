import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wkit',
  templateUrl: './wkit.component.html',
  styleUrls: ['./wkit.component.css']
})
export class WkitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
