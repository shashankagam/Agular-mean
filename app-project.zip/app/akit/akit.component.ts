import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-akit',
  templateUrl: './akit.component.html',
  styleUrls: ['./akit.component.css']
})
export class AkitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
