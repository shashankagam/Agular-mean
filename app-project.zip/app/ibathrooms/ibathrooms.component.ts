import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ibathrooms',
  templateUrl: './ibathrooms.component.html',
  styleUrls: ['./ibathrooms.component.css']
})
export class IbathroomsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
