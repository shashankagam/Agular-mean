import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ibedrooms',
  templateUrl: './ibedrooms.component.html',
  styleUrls: ['./ibedrooms.component.css']
})
export class IbedroomsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
